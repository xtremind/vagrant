//enable one of the display modes
//if no config-gamebuino.h is present, it defaults to RGB

#define DISPLAY_MODE DISPLAY_MODE_RGB565
//#define DISPLAY_MODE DISPLAY_MODE_INDEX
//#define DISPLAY_MODE DISPLAY_MODE_INDEX_HALFRES
